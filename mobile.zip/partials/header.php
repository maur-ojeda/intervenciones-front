<div class="header-mobile-content">
    <div class="row">
        <div class="col-9 offset-1">
        <h1 class="text-center">Sistema de Requerimientos Corporativo</h1>
        </div>
        <div class="col-2" style="padding-top:10px">
        <div class="float-right dropdown open">
        <button class="btn btn-secondary dropdown-toggle" type="button" id="userData" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user-circle"></i>
        </button>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userData">
        <button class="dropdown-item disabled" href="#">[Nombre de usuario]</button>    
        <button class="dropdown-item" href="#">Perfil</button>
            <button class="dropdown-item" href="#">Cerrar sesión</button>
        </div>
    </div>
        </div>
    </div>
    
 
</div>