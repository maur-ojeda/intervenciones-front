<nav class="sidebar-mobile">
                <!-- close sidebar menu -->
                <div class="dismiss">
                    <i class="fas fa-arrow-left"></i>
                </div>
                <div class="sidebar-mobile-header">
                    <div class="sidebar-mobile-imagen"><img src="https://clientes.srb.agenciasur.cl/assets/img/logo-bcoestado.jpg" alt="Banco Estado"></div>
                    <div class="sidebar-mobile-slogan">Sistema de Requerimientos Corporativo</div>
                </div>


                <ul class="list-unstyled menu-elements">
                    <li>
                        <p>
                            name tag
                        </p>
                    </li>
                    <li>
                        <a href="#drop1" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle" role="button" aria-controls="otherSections">
                         drop down 
                    </a>
                        <ul class="collapse list-unstyled" id="drop1">
                            <li>
                                <a class="scroll-link" href="javascript:;"> item drop</a>
                            </li>
                            <li>
                                <a href="#drop2" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle" role="button" aria-controls="otherSections">
                                drop down 2 
                           </a>
                                <ul class="collapse list-unstyled" id="drop2">
                                    <li>
                                        <a href="javascript:;"> item drop</a>
                                    </li>
                                    <li>

                                        <a href="#drop3" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle" role="button" aria-controls="otherSections">
                                        drop down 3 
                                   </a>
                                        <ul class="collapse list-unstyled" id="drop3">
                                            <li>
                                                <a href="javascript:;"> item drop</a>
                                            </li>
                                            <li>
                                                <a href="#drop4" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle" role="button" aria-controls="otherSections">
                                                drop down 4 
                                           </a>
                                                <ul class="collapse list-unstyled" id="drop4">
                                                    <li>
                                                        <a href="javascript:;"> item drop</a>
                                                    </li>
                                                    <li>
                                                        <a href="#drop5" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle" role="button" aria-controls="otherSections">
                                                        drop down 5 
                                                   </a>
                                                        <ul class="collapse list-unstyled" id="drop5">
                                                            <li>
                                                                <a href="javascript:;"> item drop</a>
                                                            </li>
                                                            <li>
                                                                <a href="javascript:;"> item drop</a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                </ul>
                                            </li>
                                        </ul>

                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>

                    <li>
                        <a class="scroll-link" href="javascript:;"> item</a>
                    </li>
                    <li>
                        <a class="scroll-link" href="javascript:;"> item</a>
                    </li>
                    <li>
                        <a class="scroll-link" href="javascript:;"> item</a>
                    </li>
                    <li>
                        <a class="scroll-link" href="javascript:;"> item</a>
                    </li>
                    <li>
                        <a class="scroll-link" href="javascript:;"> item</a>
                    </li>
                    <li>
                        <a href="#dropdownn" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle" role="button" aria-controls="otherSections">
                         drop down 
                    </a>
                        <ul class="collapse list-unstyled" id="dropdownn">
                            <li>
                                <a class="scroll-link" href="javascript:;"> item drop</a>
                            </li>
                            <li>
                                <a class="scroll-link" href="javascript:;"> item drop</a>
                            </li>
                        </ul>
                    </li>
                </ul>

            </nav>
            <!-- / sidebar -->
            <!-- overlay -->
            <div class="overlay-mobile"></div>
            <!-- / overlay -->