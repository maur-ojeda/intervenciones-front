<div class="link-module">
<div class="card">
  <div class="card-body">
    <h6 class="card-title">Nombre de módulo</h6>
    <div class="card-subtitle mb-2 text-muted">
      <small>En esta sección encontrarás tus solicitudes cerradas, ya sea un proceso parcial(rechazado)o completo.</small></div>
    <a href="#" class="btn btn-block btn-customized">Ir a módulo</a>
    
  </div>
</div>
</div>





